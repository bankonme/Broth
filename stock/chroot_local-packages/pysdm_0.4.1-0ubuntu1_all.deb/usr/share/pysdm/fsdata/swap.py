from constants import *

options = []
options.append( \
	{"sw": 	[0, ["sw", ""], _("Swap device"), G_M] \
	} \
	)

defaults = ["sw"]
