G_M = 0 #mounting options
G_S = 1 #special files options
G_J = 2 #journaling options
G_Q = 3 #quota options
G_P = 4 #performance options
G_O = 5 #other options

GROUPS = [_("Mounting"), _("Special Files"), _("Journaling"), _("Quota"), _("Performance"), _("Miscellaneous")]
